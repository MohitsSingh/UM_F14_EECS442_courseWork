% fundamental matrix

clc; close all; clear all;
%%
%load image infomations
[x1, x2] = readTextFiles('set1');
im1 = imread('set1/image1.jpg');
im2 = imread('set1/image2.jpg');

%%
% constants
n = length(x1(1,:));
[h,w] = size(im1);


%%
%method 1
F1 = fundermental_matrix(x1,x2);

%%
%method 2

c1 = [mean(x1(1,:)),mean(x1(2,:))]';
t1 = eye(3);
t1(1:2,3) = -c1;
x21 = t1*x1;
s1 = sqrt(mean(sum(x21(1:2,:).^2))/2);
s1 = [1/s1,0,0;0,1/s1,0;0,0,1];
x21 = s1*x21;

c2 = [mean(x2(1,:)),mean(x2(2,:))]';
t2 = eye(3);
t2(1:2,3) = -c2;
x22 = t2*x2;

s2 = sqrt(mean(sum(x22(1:2,:).^2))/2);
s2 = [1/s2,0,0;0,1/s2,0;0,0,1];
x22 = s2*x22;


F2 = fundermental_matrix(x21,x22);
F2 = (s1*t1)'*F2*(s2*t2);
%%
%calculate epipolar line and error
L11 = F1*x2;
L12 = F1'*x1;

error11 = sum(abs(sum(L11.*x1)./sqrt((L11(1,:).^2)+L11(2,:).^2)))/n;
error12 = sum(abs(sum(L12.*x2)./sqrt((L12(1,:).^2)+L12(2,:).^2)))/n;

L21 = F2*x2;
L22 = F2'*x1;

error21 = sum(abs(sum(L21.*x1)./sqrt((L21(1,:).^2)+L21(2,:).^2)))/n;
error22 = sum(abs(sum(L22.*x2)./sqrt((L22(1,:).^2)+L22(2,:).^2)))/n;
%%
%visualization
figure(1);hold on;

Title = sprintf('image 1 with linear method\n average distance:%d',error11);
subplot(1,2,1),hold on,title(Title);
imshow(im1);hold on;
plot(x1(1,:),x1(2,:),'ro');
for i = 1:n
    if L11(2,i)==0
        p1 = [-L11(3,i)/L11(1,i),max(x1(2,i)-10,1)];
        p2 = [-L11(3,i)/L11(1,i),min(x1(2,i)+10,h)];
        
        
    else
        p1 = [max(x1(1,i)-10,1),min(x1(1,i)+10,w)];
        p2 = [-(L11(3,i)+L11(1,i)*max(x1(1,i)-5,1))/L11(2,i),-(L11(3,i)+L11(1,i)*min(x1(1,i)+5,w))/L11(2,i)];
        
    end
        plot(p1,p2,'g');
       % plot(x1(1,i),x1(2,i),'ro');
end


Title = sprintf('image 2 with linear method\n average distance:%d',error12);
subplot(1,2,2),hold on,title(Title);
imshow(im2);hold on;
plot(x2(1,:),x2(2,:),'ro');
for i = 1:n
    if L12(2,i)==0
        p1 = [-L12(3,i)/L12(1,i),max(x2(2,i)-10,1)];
        p2 = [-L12(3,i)/L12(1,i),min(x2(2,i)+10,h)];
        
        
    else
        p1 = [max(x2(1,i)-10,1),min(x2(1,i)+10,w)];
        p2 = [-(L12(3,i)+L12(1,i)*max(x2(1,i)-5,1))/L12(2,i),-(L12(3,i)+L12(1,i)*min(x2(1,i)+5,w))/L12(2,i)];
        
    end
        plot(p1,p2,'g');
       % plot(x1(1,i),x1(2,i),'ro');
end


figure(2);
Title = sprintf('image 1 with normalized method\n average distance:%d',error21);
subplot(1,2,1),title(Title);hold on;
imshow(im1);hold on;
plot(x1(1,:),x1(2,:),'ro');
for i = 1:n
    if L21(2,i)==0
        p1 = [-L21(3,i)/L21(1,i),max(x1(2,i)-10,1)];
        p2 = [-L21(3,i)/L21(1,i),min(x1(2,i)+10,h)];
        
        
    else
        p1 = [max(x1(1,i)-10,1),min(x1(1,i)+10,w)];
        p2 = [-(L21(3,i)+L21(1,i)*max(x1(1,i)-5,1))/L21(2,i),-(L21(3,i)+L21(1,i)*min(x1(1,i)+5,w))/L21(2,i)];
        
    end
        plot(p1,p2,'g');
       % plot(x1(1,i),x1(2,i),'ro');
end


Title = sprintf('image 2 with normalized method\n average distance:%d',error22);
subplot(1,2,2),title(Title);hold on;
imshow(im2);hold on;
plot(x2(1,:),x2(2,:),'ro');
for i = 1:n
    if L22(2,i)==0
        p1 = [-L22(3,i)/L22(1,i),max(x2(2,i)-10,1)];
        p2 = [-L22(3,i)/L22(1,i),min(x2(2,i)+10,h)];
        
        
    else
        p1 = [max(x2(1,i)-10,1),min(x2(1,i)+10,w)];
        p2 = [-(L22(3,i)+L22(1,i)*max(x2(1,i)-5,1))/L22(2,i),-(L22(3,i)+L22(1,i)*min(x2(1,i)+5,w))/L22(2,i)];
        
    end
        plot(p1,p2,'g');
       % plot(x1(1,i),x1(2,i),'ro');
end

