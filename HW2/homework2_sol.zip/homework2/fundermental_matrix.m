function F = fundermental_matrix(x1,x2)
n = length(x1(1,:));
A = zeros(n,9);


%form A for the equation

for i = 1:n
    xx1 = x1(:,i);
    xx2 = x2(:,i);
    A(i,:) = reshape(xx2*xx1',1,9);
end


%calculate F with SVD
[u s v] = svd(A,0);
s = diag(s);
[min_s min_id]= min(s);
F = reshape(v(:,min_id),3,3)';

% 2-rank constraint
[u s v] = svd(F);

s = diag(s);
[min_s min_id] = min(s);
F = F - u(:,min_id)*min_s*v(:,min_id)';
end