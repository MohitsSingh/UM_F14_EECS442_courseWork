

clc; close all; clear all;
%%
%load image infomations
[x1, x2] = readTextFiles('set2');
im1 = imread('set2/image1.jpg');
im2 = imread('set2/image2.jpg');

%%
% constants
n = length(x1(1,:));
[h,w] = size(im1(:,:,1));


%%
%use normalized method for F

c1 = [mean(x1(1,:)),mean(x1(2,:))]';
t1 = eye(3);
t1(1:2,3) = -c1;
x21 = t1*x1;
s1 = sqrt(mean(sum(x21(1:2,:).^2))/2);
s1 = [1/s1,0,0;0,1/s1,0;0,0,1];
x21 = s1*x21;

c2 = [mean(x2(1,:)),mean(x2(2,:))]';
t2 = eye(3);
t2(1:2,3) = -c2;
x22 = t2*x2;

s2 = sqrt(mean(sum(x22(1:2,:).^2))/2);
s2 = [1/s2,0,0;0,1/s2,0;0,0,1];
x22 = s2*x22;


F2 = fundermental_matrix(x21,x22);
F2 = (s1*t1)'*F2*(s2*t2);



%%
%calculate epipoles with F
%F2 = F2';
[u s v] = svd(F2);

e2 = v(:,3);
e2 = e2/e2(3);
e1 = u(:,3);
e1 = e1/e1(3);
b1 = [-1;0;1];
if e1(3)<0, e1=-e1; end;
if e2(3)<0, e2=-e2; end;
%H1
%the center of the image,x0 in the book
c = [-h/2,-w/2,1]';
r = MAKEHGTFORM('zrotate',-atan((e1(2)+c(2))/(e1(1)+c(1))));
r = r(1:3,1:3);
t = eye(3);
t(1:3,3) = c;

G = eye(3);
normal = 1/e1(3);
f =normal*r*t*e1;
f = f(1);
G(3,1) = -1/f;

H1 = G*r*t;
H1 = H1./norm(H1*e1);
%H1
cross_e = [0,-e1(3),e1(2);e1(3),0,-e1(1);-e1(2),e1(1),0];
M = pinv(cross_e)*F2;
[u s v] = svd(cross_e);
M = M+[v(:,3),v(:,3),v(:,3)];

H0 = H1*M;
H0*e2
xx1 = H1*x1;
xx2 = H0*x2;



% a linear equation for a b c;
A = zeros(n,3);
b = zeros(n,1);
for i = 1:n
    xx2(:,i) = xx2(:,i)./xx2(3,i);
    A(i,:) = [xx2(1,i),xx2(2,i),1];
    xx1(:,i) = xx1(:,i)./xx1(3,i);
    b(i) = xx1(1,i);
end

x = A\b;

HA = [x(1),x(2),x(3);0,1,0;0,0,1];

H2 = HA*H0;
H2 = H2./norm(H2*e2);


%test the 





%%
%calculate transformed errors.

% err1 = mean(sum(((H1-eye(3))*x1).^2));
% err2 = mean(sum(((H2-eye(3))*x2).^2));

%%
%draw transform image
figure;
subplot(1,2,1);imshow(im1);
subplot(1,2,2);imshow(im2);

figure;
tform = maketform('projective',H1');

imm1 = imtransform(im1,tform);
subplot(1,2,1);imshow(imm1);

tform = maketform('projective',H2');
imm2 = imtransform(im2,tform);
subplot(1,2,2);imshow(imm2);
%%
%generate a sample image for reference

[h,w] = size(imm1(:,:,1));[h2,w2] = size(imm2(:,:,1));
whole = zeros(h,w+w2,3);
whole(1:h,1:w,:) = imm1;

whole(1:h2,w+1:w+w2,:) = imm2;
figure;
imshow(uint8(whole))
hold on;
x = [0,w+w2];
y = [0,h];
plot(x,y,'r-');


